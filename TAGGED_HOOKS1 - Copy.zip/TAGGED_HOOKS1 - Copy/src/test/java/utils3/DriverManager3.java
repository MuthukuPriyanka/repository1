package utils3;

import org.openqa.selenium.WebDriver;

public class DriverManager3 {
	
	public static WebDriver driver = null;

}
