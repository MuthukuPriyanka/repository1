package STEPS3;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utils3.DriverManager3;

public class Hooks3 {
	
	static WebDriver driver;
	
	@Before
	public void openChromeBrowser(){
        System.out.println("This will run before the Scenario");
        
    	driver=new ChromeDriver(); //1122
    	driver.manage().window().maximize();
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    	
	}

	
	@After
    public void closeBrowser(){
		
        System.out.println("This will run after the Scenario");
               
        driver.quit();
        
        }
	
	
	@Before("@FIRST")
	public void beforeFirst() {
		System.out.println("This will run only before the Scenario");
		
	}
	
	@After("@FIRST")
	public void afterFirst() {
		System.out.println("This will run only after the Scenario");
		
	}
	
	@Before("@SECOND")
	public void beforeSECOND() {
		System.out.println("This will run only before the Scenario");
		
	}
	
	@After("@SECOND")
	public void afterSECOND() {
		System.out.println("This will run only after the Scenario");
		
	}
	
}
